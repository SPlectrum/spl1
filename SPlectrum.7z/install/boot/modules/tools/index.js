//  name        The tools Package
//  URI         tools
//  type        Module Package
//  description The tools package contains utility APIs and tools
//              for various development and system operations.
//              Currently includes git and 7zip wrapper APIs.
///////////////////////////////////////////////////////////////////////////////