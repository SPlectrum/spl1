//  name        The spl/avro API
//  URI         spl/avro
//  type        API Module
//  description The avro API manages AVRO in memeory BLOB and file containers.
///////////////////////////////////////////////////////////////////////////////
