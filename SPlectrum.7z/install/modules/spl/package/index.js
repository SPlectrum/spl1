//  name        Package API
//  URI         spl/package
//  type        API Module
//  description This API manages data and module packages.
///////////////////////////////////////////////////////////////////////////////
