//  name        Void API
//  URI         spl/void
//  type        API Module
//  description This API contains methods with no input from or output into
//              the data that is passed through.
//              The can have side effects however.
///////////////////////////////////////////////////////////////////////////////
