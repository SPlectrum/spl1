//  name        The spl/blob API
//  URI         spl/blob
//  type        API Module
//  description A standard filesystem API for dirs and binary and text files
///////////////////////////////////////////////////////////////////////////////
