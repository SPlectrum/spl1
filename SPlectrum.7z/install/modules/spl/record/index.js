//  name        The spl/record API
//  URI         spl/record
//  type        API Module
//  description The record API data records with AVRO schemas
//              It is the generic handler of data records.
///////////////////////////////////////////////////////////////////////////////
