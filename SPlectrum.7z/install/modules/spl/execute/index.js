//  name        Execution API
//  URI         spl/execute
//  type        API Module
//  description This module manages the execution flow.
///////////////////////////////////////////////////////////////////////////////
