//  name        The spl Package
//  URI         spl
//  type        Module Package
//  description The spl package contains the minimal core functionality
//              for a running SPlectrum install that can be extended
//              with additional modules.
///////////////////////////////////////////////////////////////////////////////
