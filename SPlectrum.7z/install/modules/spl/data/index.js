//  name        Data API
//  URI         spl/data
//  type        API Module
//  description This API implements the data record API.
//              IIt deals with utf8 files only.
///////////////////////////////////////////////////////////////////////////////
