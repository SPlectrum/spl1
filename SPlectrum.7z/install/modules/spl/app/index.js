//  name        app API
//  URI         spl/app
//  type        API Module
//  description This API contains the common app methods
///////////////////////////////////////////////////////////////////////////////
