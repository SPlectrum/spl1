//  name        Console API
//  URI         spl/console
//  type        API Module
//  description This API implements the console API
///////////////////////////////////////////////////////////////////////////////
