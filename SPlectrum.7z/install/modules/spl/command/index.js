//  name        Command API
//  URI         spl/command
//  type        API Module
//  description This API implements the commandline parsing and command execution.
///////////////////////////////////////////////////////////////////////////////
